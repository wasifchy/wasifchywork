


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta name="description" content="This page is not available at the moment or doesn't exist.">
    <meta name=”robots” content="index, follow">
    <meta name="keywords" content="404,error,not found">

    <meta property="og:image" content=""/>
    <meta property='og:image:width' content='1200' />
    <meta property='og:image:height' content='627' />
    

    <title>Page Not Found - 404 Error</title>
    <link rel="shortcut icon" type="image/png" href="https://django-pouyaeti-staticfiles.s3.amazonaws.com/static/images/favicon-pouyaeti-new.svg"/>
    <link rel="stylesheet" href="https://django-pouyaeti-staticfiles.s3.amazonaws.com/static/main.css">

    <!-- Google Tag Manager -->
    <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
    new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
    j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
    'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
    })(window,document,'script','dataLayer','GTM-NFNZ6SW3');</script>
    <!-- End Google Tag Manager -->

    
<link rel="stylesheet" href="https://django-pouyaeti-staticfiles.s3.amazonaws.com/static/workstation/sw.css">

    

    <!-- Meta Pixel Code -->
    <script>
    !function(f,b,e,v,n,t,s)
    {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
    n.callMethod.apply(n,arguments):n.queue.push(arguments)};
    if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
    n.queue=[];t=b.createElement(e);t.async=!0;
    t.src=v;s=b.getElementsByTagName(e)[0];
    s.parentNode.insertBefore(t,s)}(window, document,'script',
    'https://connect.facebook.net/en_US/fbevents.js');
    fbq('init', '837690838378812');
    fbq('track', 'PageView');
    </script>
    <noscript><img height="1" width="1" style="display:none"
    src="https://www.facebook.com/tr?id=837690838378812&ev=PageView&noscript=1"
    /></noscript>
    <!-- End Meta Pixel Code -->


    <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=AW-874859097"></script>
    <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'AW-874859097');
    </script>


</head>
<body>

    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NFNZ6SW3"
    height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->

    

<header id="main-navigation">

     <!-- Mobile Menu Icon (visible only on mobile) -->
    <div id="mobile-menu-icon" onclick="toggleMobileMenu()">
        <span class="line"></span>
        <span class="line"></span>
        <span class="line"></span>
    </div>

    <a href="/" >
        <img id="dalaran-logo" src="https://django-pouyaeti-staticfiles.s3.amazonaws.com/static/images/pouyaeti-logo-new.svg" width="150" height="15">
    </a>

      
    <!-- Updated Navigation with text labels only -->
    <nav>
        <a href="https://university.pouyaeti.com/store" target="_blank" class="nav-btn-a">Programs</a>
        <a href="/all-workstations" class="nav-btn-a">Workstations</a>
        <a href="/tools/" class="nav-btn-a">Tools</a>
    </nav>

    <!-- 
    <nav>
        <a href="/" class="nav-btn-a">
            <svg version="1.1" class="nav-icon" x="0px" y="0px" viewBox="0 0 150 150"  xml:space="preserve">
                <path d="M144.2,66.3l-18.6,69.2c-1.2,4.4-5.2,7.5-9.8,7.5H92.3v-39.3c0-6-4.8-10.8-10.8-10.8H68.5c-6,0-10.8,4.8-10.8,10.8v39.3
                H34.2c-4.6,0-8.6-3.1-9.8-7.5L5.8,66.3c-1.1-4,0.4-8.3,3.8-10.8L69,12.4c3.5-2.6,8.4-2.6,11.9,0l59.4,43.2
                C143.7,58,145.3,62.3,144.2,66.3z"/>
            </svg>
            <div class="menu-btn-bg" id="bg-1"></div>
            <div class="btn-hover" id="point-1"></div>
            <span class="nav-label">Home</span> 
        </a>
        
        <a href="/courses/" class="nav-btn-a">
            <svg class="nav-icon" enable-background="new 0 0 27 27"  viewBox="0 0 27 27" ><g id="_x34_2"><path d="m22.980011 23.5h-16.8700562c-.546196 0-1.0899658-.436224-1.0899658-1.0900269 0-.6099854.4899902-1.0999756 1.0899658-1.0999756h16.8700562c.5641956 0 1-.4721775 1-1 0-.1218643-.0099354-16.2082233-.0100098-16.3300171 0-1.369995-1.1100464-2.4799804-2.4800415-2.4799804-4.069788 0-11.5733242 0-15.3800049 0-1.6551656 0-3.0899658 1.3547404-3.0899658 3.0900269v17.8199463c0 1.7591304 1.4345961 3.0900268 3.0899658 3.0900268h16.8700562c.5499878 0 1-.4500122 1-1s-.4500122-1-1-1zm-17.960022-18.9099731c0-.5900269.5-1.0900269 1.0899658-1.0900269h.9200439v15.8099976c-.6289024.0393009-1.1578493-.1068573-2.0100098.2000122v-14.9199829zm7.210022 4.9799804c0-.5300293.289978-1.0200195.75-1.2700195.4599609-.2600098 1.0299683-.2399902 1.4799805.0499878l2.8599854 1.8400269c.4199829.2600098.6699829.7199707.6699829 1.2199707 0 .4900513-.25.9500122-.6699829 1.210022l-2.8599854 1.8400269c-.4229841.2819529-.9989243.3124065-1.4799805.0499878-.460022-.25-.75-.7399902-.75-1.2700195z"></path></g></svg>

            <div class="menu-btn-bg" id="bg-2"></div>
            <div class="btn-hover" id="point-2"></div>
            <span class="nav-label">Courses</span> 
        </a>

        <a href="/all-workstations" class="nav-btn-a">
            <svg class="nav-icon" viewBox="0 -45 512 512"><path d="m512 76.1875v193.65625c0 8.316406-6.742188 15.058594-15.058594 15.058594h-23.292968v-152.734375c0-18.054688-14.632813-32.6875-32.6875-32.6875h-198.09375c-.980469 0-1.875-.554688-2.308594-1.4375l-20.4375-41.453125c-5.554688-11.253906-16.785156-18.230469-29.324219-18.230469h-53.863281v-23.300781c0-8.316406 6.742187-15.058594 15.058594-15.058594h107.269531c.996093 0 1.878906.550781 2.308593 1.4375l20.441407 41.460938c5.550781 11.242187 16.785156 18.230468 29.324219 18.230468h185.605468c8.316406 0 15.058594 6.742188 15.058594 15.058594zm0 0"></path><path d="m443.53125 132.167969v206.144531c0 8.316406-6.742188 15.058594-15.058594 15.058594h-23.289062v-152.738282c0-18.050781-14.636719-32.6875-32.6875-32.6875h-198.09375c-.984375 0-1.878906-.550781-2.308594-1.433593l-20.441406-41.453125c-5.640625-11.425782-16.976563-18.230469-29.324219-18.230469h-53.859375v-23.292969c0-8.316406 6.742188-15.058594 15.058594-15.058594h107.269531c.992187 0 1.875.542969 2.308594 1.425782l20.4375 41.460937c5.554687 11.246094 16.785156 18.234375 29.324219 18.234375h198.09375c1.414062 0 2.570312 1.15625 2.570312 2.570313zm0 0"></path><path d="m372.496094 198.0625h-198.09375c-12.539063 0-23.773438-6.984375-29.324219-18.230469-10.300781-20.902343-5.765625-11.683593-20.441406-41.453125-.429688-.890625-1.316407-1.433594-2.308594-1.433594h-107.269531c-8.316406 0-15.058594 6.742188-15.058594 15.058594v254.785156c0 8.316407 6.742188 15.058594 15.058594 15.058594h344.949218c8.316407 0 15.058594-6.742187 15.058594-15.058594v-206.15625c0-1.414062-1.15625-2.570312-2.570312-2.570312zm-88.386719 174.976562c0 8.351563-6.804687 15.058594-15.058594 15.058594-8.242187 0-15.058593-6.699218-15.058593-15.058594 0-5.492187 0-4.320312 0-9.800781 0-8.273437 6.714843-15.058593 15.058593-15.058593 8.332031 0 15.058594 6.785156 15.058594 15.058593zm49.375 0c0 8.351563-6.808594 15.058594-15.058594 15.058594-8.292969 0-15.0625-6.726562-15.0625-15.058594 0-5.492187 0-4.320312 0-9.800781 0-8.28125 6.71875-15.058593 15.0625-15.058593 8.332031 0 15.058594 6.785156 15.058594 15.058593zm0 0"></path></svg>
            <div class="menu-btn-bg" id="bg-3"></div>
            <div class="btn-hover" id="point-3"></div>
            <span class="nav-label">Workstations</span> 
        </a>

        <a href="/tools/" class="nav-btn-a">
            <svg class="nav-icon" viewBox="0 0 469.336 469.336">
                <path d="M459.95 137.237L331.971 9.089c-12.063-12.12-33.219-12.11-45.26-0.01l-42.656 42.713c-6.052 6.039-9.385 14.091-9.385 22.665 0 8.574 3.333 16.626 9.375 22.655l127.99 128.159c6.031 6.06 14.073 9.398 22.635 9.398s16.604-3.338 22.625-9.387l42.656-42.713c6.052-6.039 9.385-14.092 9.385-22.665 0-8.574-3.334-16.626-9.386-22.655z"/>
                <path d="M235.127 118.543c-3.5-3.51-8.938-4.135-13.115-1.552-31.146 19.094-79.938 41.854-135.521 41.854-4.76 0-8.948 3.156-10.26 7.74L0.408 431.97c-1.344 4.729 0.708 9.76 4.979 12.198 4.26 2.406 9.656 1.646 13.031-1.948l126.885-134.344c4.26-4.521 6.271-10.885 5.51-17.469-1.469-12.875 4.427-24.615 15.76-31.396 9.958-5.938 23.177-5.646 32.979 0.698 8.49 5.531 13.74 13.979 14.76 23.781 1.01 9.656-2.344 19.125-9.198 25.979-6.865 6.865-16.365 10.125-26.219 9.031-6.719-0.792-12.885 1.229-17.427 5.531L27.117 450.918c-3.573 3.375-4.375 8.75-1.948 13.031 1.938 3.396 5.51 5.385 9.271 5.385 0.969 0 1.958-0.135 2.927-0.406L305.79 392.294c4.583-1.313 7.74-5.5 7.74-10.26 0-55.583 22.76-104.375 41.854-135.521 2.573-4.198 1.938-9.625-1.552-13.115L235.127 118.543z"/>
            </svg>
              
            <div class="menu-btn-bg" id="bg-4"></div>
            <div class="btn-hover" id="point-4"></div>
            <span class="nav-label">Tools</span> 
        </a>

    </nav>
-->
    
        <div id="right-menu-container">
    
        
               <!-- If user is not logged in -->
        <p id="right-menu-signin">
            <a href="/user/signup/">Sign Up</a>
              <span class="seperator">|</span> 
            <a href="/user/signin/">Login</a>
        </p>
        <script>
            setTimeout(function() {
                document.getElementById("bg-1").style.display = "block";
                document.getElementById("point-1").style.display = "block";
                document.getElementById("bg-2").style.display = "block";
                document.getElementById("point-2").style.display = "block";
                document.getElementById("bg-3").style.display = "block";
                document.getElementById("point-3").style.display = "block";
                document.getElementById("bg-4").style.display = "block";
                document.getElementById("point-4").style.display = "block";
                }, 100);
        </script>
            
        
        
    </div>
</header>

<!-- Mobile Menu Dropdown (appears when hamburger is clicked) -->
<div id="mobile-menu-dropdown">
    <nav>
      <a href="https://university.pouyaeti.com/store" target="_blank" class="mobile-nav-link" onclick="toggleMobileMenu()">Programs</a>
      <a href="/all-workstations" class="mobile-nav-link" onclick="toggleMobileMenu()">Workstations</a>
      <a href="/tools/" class="mobile-nav-link" onclick="toggleMobileMenu()">Tools</a>
    </nav>
</div>
  
<script>
    function toggleMobileMenu() {
        var mobileMenu = document.getElementById("mobile-menu-dropdown");
        var isShowing = mobileMenu.classList.contains("show");
        mobileMenu.classList.toggle("show");
        
        // Optional: animate hamburger icon
        var icon = document.getElementById("mobile-menu-icon");
        icon.classList.toggle("active");
    }
</script>

<main id="sw-container" style="text-align: center; margin-top: 50px;">
    <div id="sw-col">
        <h1>404 - Page Not Found</h1>
        <div class="sw-row" style="display: flex; justify-content: center; align-items: center; margin: 40px 0;">
            <!-- SVG Placeholder -->
            <div>
                <img src="https://django-pouyaeti-staticfiles.s3.amazonaws.com/static/images/404-error.svg" onerror="this.onerror=null; this.src='https://django-pouyaeti-staticfiles.s3.amazonaws.com/static/images/404-error.png'" alt="404 Error Illustration" style="max-width: 300px; height: auto;">
            </div>
        </div>
        <p class="text-404" >Oops! The page you are looking for might have been removed, had its name changed, or is temporarily unavailable.</p>
        <a href="/" style="display: inline-block; margin-top: 30px; font-size: 16px; text-decoration: none; color: white; background-color: #007bff; padding: 10px 20px; border-radius: 5px;">Return to Home Page</a>
    </div>
</main>



<footer class="site-footer">
    <div class="container-footer">
        <div class="footer-column">
            <h3>About Pouyaeti</h3>
            <ul>
                <li><a href="https://pouyaeti.com/terms">Terms of Use</a></li>
                <li><a href="https://pouyaeti.com/privacy">Privacy Policy</a></li>
                <li><a href="https://pouyaeti.com/about">About Pouya</a></li>
                <li><a href="https://pouyaeti.com/courses">All Courses</a></li>
            </ul>
        </div>
        <div class="footer-column course-col">
            <h3>Top Courses</h3>
            <ul>
                <li><a href="https://www.udemy.com/course/digital-marketing-strategy-course-wordpress-seo-instagram-facebook/?referralCode=68D31DD0CA1C1D9EB477">Digital Marketing Course</a></li>
                <li><a href="https://www.udemy.com/course/social-media-marketing-agency-digital-business-facebook-ads-instagram/?referralCode=594B267E4FB891CFD088">Social Media Marketing Agency</a></li>
                <li><a href="https://www.udemy.com/course/chatgpt-mega-course-midjourney-adobe-firefly-ai-chatgpt-4-generative/?referralCode=B04C7948C5EF3B893E27">ChatGPT Course</a></li>
                <li><a href="https://www.udemy.com/course/mega-google-analytics-4-course-google-tag-manager-digital-marketing/?referralCode=0FE252F6CB1D33832315">Google Analytics Course</a></li>
                <li><a href="https://www.udemy.com/course/best-ecommerce-marketing-course-agency-affiliate-freelancer-social-ads/?referralCode=52B2F177A205442D6D98">E-Commerce and Marketing Course</a></li>
                <li><a href="https://www.udemy.com/course/mega-web-development-course-fullstack-javascript-python-django-backend/?referralCode=3FFE48D2C20D68DD960F">Web Development Course</a></li>
            </ul>
        </div>
        <div class="footer-column">
            <h3>Follow Us</h3>
            <ul>
                <li><a href="https://www.udemy.com/user/pouyaet/">Udemy</a></li>
                <li><a href="https://www.youtube.com/pouyaeti">YouTube</a></li>
                <li><a href="https://twitter.com/pouyaeti">X</a></li>
                <li><a href="https://www.instagram.com/pouyaeti/">Instagram</a></li>
                <li><a href="https://www.linkedin.com/in/pouyaeti/">Linkedin</a></li>
            </ul>
        </div>
        
    </div>

    <div class="footer-bottom">
        <div class="footer-logo">
            <a href="/" >
                <img id="dalaran-logo" src="https://django-pouyaeti-staticfiles.s3.amazonaws.com/static/images/pouyaeti-logo-new.svg" width="100" height="15">
            </a>
        </div>
        <div class="copyright">
            Copyright © 2024 pouyaeti.com
        </div>
    </div>
    
</footer>


</body>
</html>